package edu.ua.cs.cs200.fall2020.team7;

import java.util.TimerTask;

/**
 * Runs main accounting procedure as a task.
 *
 * @author Ashton J. (11797181)
 */
public class Task extends TimerTask {
  public void run() {
    ReportGenerator.runMainAccountingProcedure();
  }
}
