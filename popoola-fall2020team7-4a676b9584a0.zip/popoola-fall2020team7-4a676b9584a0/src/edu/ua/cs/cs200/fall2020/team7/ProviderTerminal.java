package edu.ua.cs.cs200.fall2020.team7;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

/**
 * GUI for Provider Terminal.
 *
 * @author Peter Zhang (11861641)
 */
public class ProviderTerminal {
  private static JTextField provLoginField;
  private static JTextField memNumField;
  private static JTextField serviceNumField;
  private static JLabel memStatusLabel;
  private static JTextArea memDetailsTextArea;
  private static JPanel datePanel;
  private static JPanel servicePanel;
  private static JLabel serviceNameLabel;
  private static JPanel billingPanel;
  private static JLabel invalidProvLabel;
  private static int providerId;
  private static JTextField emailTextBox;
  private static JLabel successLabel;
  private static JComboBox dayComboBox;
  private static JComboBox monthComboBox;
  private static JComboBox yearComboBox;
  private static JTextArea commentArea;
  private static Service serviceGot;

  /** Main entry point. */
  public static void main(String[] args) {

    // set up the login page
    createLoginGui();
  }

  /** Create the Login GUI. */
  public static void createLoginGui() {
    // set up the login page
    JFrame loginFrame = new JFrame("ChocAn Provider Terminal Login");
    loginFrame.setResizable(false);
    loginFrame.setSize(400, 250);
    loginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    loginFrame.getContentPane().setLayout(null);

    JLabel provLoginLabel = new JLabel("Provider Login");
    provLoginLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
    provLoginLabel.setBounds(10, 11, 155, 40);
    loginFrame.getContentPane().add(provLoginLabel);

    JTextArea descTextArea = new JTextArea();
    descTextArea.setEditable(false);
    descTextArea.setBackground(UIManager.getColor("Button.background"));
    descTextArea.setLineWrap(true);
    descTextArea.setFont(new Font("Tahoma", Font.PLAIN, 13));
    descTextArea.setText("Please enter your provider number in the field below");
    descTextArea.setBounds(10, 50, 155, 50);
    loginFrame.getContentPane().add(descTextArea);

    provLoginField = new JTextField();
    provLoginField.setBounds(10, 100, 155, 30);
    loginFrame.getContentPane().add(provLoginField);
    provLoginField.setColumns(10);

    JButton loginButton = new JButton("Login");
    loginButton.setBounds(10, 150, 90, 25);
    loginButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            providerId = Integer.parseInt(provLoginField.getText());
            Provider providerGot = AccountManagementMenu.getProvider(providerId);
            if (providerGot != null) {
              createProvTermGui();
              loginFrame.dispose();
            } else {
              invalidProvLabel.setVisible(true);
            }
          }
        });
    loginFrame.getContentPane().add(loginButton);

    // if we want to put a picture of chocolate bar or something lol
    JLabel pictureLabel = new JLabel("");
    pictureLabel.setBounds(230, 30, 155, 150);
    loginFrame.getContentPane().add(pictureLabel);

    invalidProvLabel = new JLabel("Invalid Number");
    invalidProvLabel.setBounds(120, 155, 110, 15);
    invalidProvLabel.setVisible(false);
    loginFrame.getContentPane().add(invalidProvLabel);

    loginFrame.setVisible(true);
  }

  /** Create the Provider Terminal GUI. */
  public static void createProvTermGui() {
    JFrame providerFrame = new JFrame("ChocAn Provider Terminal");
    providerFrame.setResizable(false);
    providerFrame.setSize(600, 500);
    providerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    providerFrame.getContentPane().setLayout(null);

    JLabel provTermLabel = new JLabel("Provider Terminal (" + providerId + ")");
    provTermLabel.setFont(new Font("Tahoma", Font.PLAIN, 26));
    provTermLabel.setBounds(10, 0, 375, 50);
    providerFrame.getContentPane().add(provTermLabel);

    JTextArea descTextArea = new JTextArea();
    descTextArea.setFont(new Font("Tahoma", Font.PLAIN, 13));
    descTextArea.setLineWrap(true);
    descTextArea.setText("Swipe member card or enter a member number to begin.");
    descTextArea.setEditable(false);
    descTextArea.setBackground(UIManager.getColor("Button.background"));
    descTextArea.setBounds(10, 40, 280, 40);
    providerFrame.getContentPane().add(descTextArea);

    memNumField = new JTextField();
    memNumField.setFont(new Font("Tahoma", Font.PLAIN, 12));
    memNumField.setBounds(20, 95, 90, 25);
    providerFrame.getContentPane().add(memNumField);
    memNumField.setColumns(10);

    JLabel memNumLabel = new JLabel("Enter member number:");
    memNumLabel.setBounds(20, 80, 160, 15);
    providerFrame.getContentPane().add(memNumLabel);

    JButton enterMemButton = new JButton("Confirm");
    enterMemButton.setBounds(120, 95, 90, 25);
    enterMemButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            int memberId = Integer.parseInt(memNumField.getText());
            Member memberGot = AccountManagementMenu.getMember(memberId);
            if (memberGot != null) {
              // if (!(memberGot
              //   .isSuspended())) { // valid membership
              if (BillChocAnMenu.validateMemberID(memberId)) {
                memStatusLabel.setText("Validated");
                memStatusLabel.setVisible(true);
                memDetailsTextArea.setVisible(false);
                datePanel.setVisible(true);
              } else { // if member has suspended membership
                memStatusLabel.setText("Suspended");
                memStatusLabel.setVisible(true);
                memDetailsTextArea.setVisible(true);
              }
            } else { // member does not exist
              memStatusLabel.setText("Invalid Number");
              memStatusLabel.setVisible(true);
            }
          }
        });
    providerFrame.getContentPane().add(enterMemButton);

    memStatusLabel = new JLabel();
    memStatusLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
    memStatusLabel.setBounds(220, 95, 140, 25);
    memStatusLabel.setVisible(false);
    providerFrame.getContentPane().add(memStatusLabel);

    memDetailsTextArea = new JTextArea();
    memDetailsTextArea.setText("Member owes fees.");
    memDetailsTextArea.setLineWrap(true);
    memDetailsTextArea.setEditable(false);
    memDetailsTextArea.setFont(new Font("Tahoma", Font.PLAIN, 12));
    memDetailsTextArea.setBackground(UIManager.getColor("Button.background"));
    memDetailsTextArea.setBounds(370, 95, 215, 25);
    memDetailsTextArea.setVisible(false);
    providerFrame.getContentPane().add(memDetailsTextArea);

    datePanel = new JPanel();
    datePanel.setBounds(10, 130, 575, 70);
    datePanel.setVisible(false);
    providerFrame.getContentPane().add(datePanel);
    datePanel.setLayout(null);

    JLabel dateLabel = new JLabel("Enter date of service:");
    dateLabel.setBounds(10, 10, 160, 15);
    datePanel.add(dateLabel);

    dayComboBox = new JComboBox();
    dayComboBox.setModel(
        new DefaultComboBoxModel(
            new String[] {
              "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
              "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28",
              "29", "30", "31"
            }));
    dayComboBox.setBounds(10, 35, 50, 20);
    datePanel.add(dayComboBox);

    monthComboBox = new JComboBox();
    // "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    monthComboBox.setModel(
        new DefaultComboBoxModel(
            new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"}));
    monthComboBox.setBounds(70, 35, 50, 20);
    datePanel.add(monthComboBox);

    yearComboBox = new JComboBox();
    yearComboBox.setModel(
        new DefaultComboBoxModel(new String[] {"2020", "2019", "2018", "2017", "2016", "2015"}));
    yearComboBox.setBounds(130, 35, 60, 20);
    datePanel.add(yearComboBox);

    JButton confirmDateButton = new JButton("Confirm");
    confirmDateButton.setBounds(250, 35, 90, 20);
    confirmDateButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            if (true) { // make it confirm date later
              servicePanel.setVisible(true);
            } else {
              // prompt invalid date
            }
          }
        });
    datePanel.add(confirmDateButton);

    servicePanel = new JPanel();
    servicePanel.setBounds(10, 200, 575, 60);
    servicePanel.setVisible(false);
    providerFrame.getContentPane().add(servicePanel);
    servicePanel.setLayout(null);

    JLabel serviceLabel = new JLabel("Enter service number:");
    serviceLabel.setBounds(10, 10, 160, 15);
    servicePanel.add(serviceLabel);

    serviceNumField = new JTextField();
    serviceNumField.setFont(new Font("Tahoma", Font.PLAIN, 12));
    serviceNumField.setColumns(10);
    serviceNumField.setBounds(10, 25, 90, 25);
    serviceNumField.addKeyListener(
        new KeyAdapter() {
          public void keyReleased(KeyEvent e) {
            if (serviceNumField.getText().length()
                == 6) { // make it look up and confirm service later
              int serviceId = Integer.parseInt(serviceNumField.getText());
              serviceGot = ProviderDirectory.lookupServiceByCode(serviceId);
              if (serviceGot != null) {
                serviceNameLabel.setText(serviceGot.getName() + " $" + serviceGot.getFee());
                serviceNameLabel.setVisible(true);
              } else {
                serviceNameLabel.setText("Invalid Service");
                serviceNameLabel.setVisible(true);
              }
            } else {
              // no text
              serviceNameLabel.setText("");
              serviceNameLabel.setVisible(false);
            }
          }
        });
    servicePanel.add(serviceNumField);

    JButton enterServiceButton = new JButton("Confirm");
    enterServiceButton.setBounds(470, 25, 90, 25);
    enterServiceButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            if (serviceGot != null) { // make it confirm service later
              billingPanel.setVisible(true);
            } else {
              // prompt invalid service
            }
          }
        });
    servicePanel.add(enterServiceButton);

    serviceNameLabel = new JLabel("");
    serviceNameLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
    serviceNameLabel.setBounds(110, 25, 350, 25);
    servicePanel.add(serviceNameLabel);

    providerFrame.setVisible(true);

    billingPanel = new JPanel();
    billingPanel.setBounds(10, 260, 575, 200);
    billingPanel.setVisible(false);
    providerFrame.getContentPane().add(billingPanel);
    billingPanel.setLayout(null);

    JLabel commentLabel = new JLabel("Enter additional comments:");
    commentLabel.setBounds(10, 10, 170, 20);
    billingPanel.add(commentLabel);

    commentArea = new JTextArea();
    commentArea.setBounds(10, 40, 555, 125);
    billingPanel.add(commentArea);

    JButton finishButton = new JButton("Submit and Logout");
    finishButton.setBounds(200, 170, 160, 25);
    finishButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            // TODO print report
            SimpleDateFormat dateSDF = new SimpleDateFormat("YYYY-MM-dd");
            SimpleDateFormat dateTimeSDF = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
            Date curDateTime;
            Date serviceDate;
            // LocalDateTime curDateTime = LocalDateTime.now();
            String year = yearComboBox.getSelectedItem().toString();
            String month = monthComboBox.getSelectedItem().toString();
            String day = dayComboBox.getSelectedItem().toString();
            LocalDate serviceDate2 = LocalDate.parse(String.format("%s-%s-%s", year, month, day));
            try {
              curDateTime = new Date();
              String newDateString = String.format("%s-%s-%s", year, month, day);
              // System.out.println(newDateString);
              serviceDate =
                  Date.from(serviceDate2.atStartOfDay(ZoneId.systemDefault()).toInstant());
              // System.out.println(serviceDate);
            } catch (Exception e2) {
              // set current date as default
              curDateTime = new Date();
              serviceDate = new Date();
            }
            int provNum = providerId;
            int memNum = Integer.parseInt(memNumField.getText());
            int servCode = Integer.parseInt(serviceNumField.getText());
            String comments = commentArea.getText();
            //            System.out.print(
            //                String.format(
            //                    "%s\n%s\n%s\n%s\n%s\n%s\n",
            //                    dateTimeSDF.format(curDateTime),
            //                    dateSDF.format(serviceDate),
            //                    provNum,
            //                    memNum,
            //                    servCode,
            //                    comments));

            Record newRecord = new Record(serviceDate, provNum, memNum, servCode, comments);
            // add record to database
            Records.addRecord(newRecord);
            BillChocAnMenu.billChocAn(newRecord);
            createLoginGui();
            providerFrame.dispose();
          }
        });
    billingPanel.add(finishButton);

    JButton provDirButton = new JButton("Request Provider Directory");
    provDirButton.setBounds(380, 10, 195, 25);
    provDirButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            createProvDirecGui();
          }
        });
    providerFrame.getContentPane().add(provDirButton);

    providerFrame.setVisible(true);
  }

  /** Create the Provider Directory GUI. */
  public static void createProvDirecGui() {
    JFrame directoryFrame = new JFrame("ChocAn Provider Directory Request");
    directoryFrame.setResizable(false);
    directoryFrame.setSize(400, 250);
    directoryFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    directoryFrame.getContentPane().setLayout(null);

    JLabel mainLabel = new JLabel("Provider Directory Request Form");
    mainLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
    mainLabel.setBounds(10, 10, 350, 40);
    directoryFrame.getContentPane().add(mainLabel);

    JLabel descLabel = new JLabel("Please enter an email below:");
    descLabel.setBounds(10, 60, 300, 15);
    directoryFrame.getContentPane().add(descLabel);

    emailTextBox = new JTextField();
    emailTextBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
    emailTextBox.setBounds(10, 90, 375, 25);
    directoryFrame.getContentPane().add(emailTextBox);
    emailTextBox.setColumns(10);

    JButton sendButton = new JButton("Send");
    sendButton.setBounds(150, 125, 90, 25);
    sendButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            // TODO make print file
            try {
              FileWriter myWriter = new FileWriter("ProviderDirectory.txt");
              PrintWriter printWriter = new PrintWriter(myWriter);
              for (Service s : ProviderDirectory.getServices()) {
                printWriter.println(s);
              }
              printWriter.close();
            } catch (IOException exception) {
              exception.printStackTrace();
            }
            //            for (Service s : ProviderDirectory.getServices()) {
            //              System.out.println(s);
            //            }
            successLabel.setVisible(true);
          }
        });
    directoryFrame.getContentPane().add(sendButton);

    successLabel = new JLabel("Success!");
    successLabel.setHorizontalAlignment(SwingConstants.CENTER);
    successLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
    successLabel.setBounds(150, 175, 90, 30);
    successLabel.setVisible(false);
    directoryFrame.getContentPane().add(successLabel);

    directoryFrame.setVisible(true);
  }
}
