package edu.ua.cs.cs200.fall2020.team7;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Entity class to manage Records.
 * @author Noah Overcash (11907775), Raymond Arndorfer (12023919)
 */
public class Records {
  /**
   * Add a Record to the database.
   * @param r the record
   */
  public static void addRecord(Record r) {
    SimpleDateFormat dateSDF = new SimpleDateFormat("YYYY-MM-dd");
    SimpleDateFormat dateTimeSDF = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");

    HashMap<String, DatabaseValue> rowData = new HashMap<String, DatabaseValue>();
    rowData.put("RECORDED_DATE_TIME", new DatabaseValue(dateTimeSDF.format(r.getRecordedTime())));
    rowData.put("SERVICE_DATE", new DatabaseValue(dateSDF.format(r.getServiceDate())));
    rowData.put("PROVIDER_ID", new DatabaseValue(r.getProviderId()));
    rowData.put("MEMBER_ID", new DatabaseValue(r.getMemberId()));
    rowData.put("SERVICE_CODE", new DatabaseValue(r.getServiceCode()));
    rowData.put("COMMENTS", new DatabaseValue(r.getComments()));
    
    Database.insert("RECORDS", rowData);
  }

  /**
   * Get all records of services rendered by a certain provider.
   * @param p the provider
   * @return the records
   */
  public static Record[] getProviderRecords(Provider p) {
    SimpleDateFormat dateSDF = new SimpleDateFormat("YYYY-MM-dd");
    SimpleDateFormat dateTimeSDF = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");

    ArrayList<HashMap<String, DatabaseValue>> allRows = Database.getValues("RECORDS", "PROVIDER_ID="+p.getId(), "SERVICE_DATE ASC");

    Record[] records = new Record[allRows.size()];

    for (int i = 0; i < allRows.size(); i++) {
      Date recordedTime, serviceDate;
      try {
        recordedTime = dateTimeSDF.parse(allRows.get(i).get("RECORDED_DATE_TIME").stringValue);
        serviceDate = dateSDF.parse(allRows.get(i).get("SERVICE_DATE").stringValue);
      } catch (ParseException e) {
        recordedTime = new Date(); // should not happen
        serviceDate = new Date(); // should not happen
      }
      records[i] = new Record(
        recordedTime,
        serviceDate,
        allRows.get(i).get("PROVIDER_ID").integerValue,
        allRows.get(i).get("MEMBER_ID").integerValue,
        allRows.get(i).get("SERVICE_CODE").integerValue,
        allRows.get(i).get("COMMENTS").stringValue
      );
    }

    return records;
  }

  /**
   * Get all records of services rendered to a certain member.
   * @param m the member
   * @return the records
   */
  public static Record[] getMemberRecords(Member m) {
    SimpleDateFormat dateSDF = new SimpleDateFormat("YYYY-MM-dd");
    SimpleDateFormat dateTimeSDF = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");

    ArrayList<HashMap<String, DatabaseValue>> allRows = Database.getValues("RECORDS", "MEMBER_ID="+m.getId(), "SERVICE_DATE ASC");

    Record[] records = new Record[allRows.size()];

    for (int i = 0; i < allRows.size(); i++) {
      Date recordedTime, serviceDate;
      try {
        recordedTime = dateTimeSDF.parse(allRows.get(i).get("RECORDED_DATE_TIME").stringValue);
        serviceDate = dateSDF.parse(allRows.get(i).get("SERVICE_DATE").stringValue);
      } catch (ParseException e) {
        recordedTime = new Date(); // should not happen
        serviceDate = new Date(); // should not happen
      }
      records[i] = new Record(
        recordedTime,
        serviceDate,
        allRows.get(i).get("PROVIDER_ID").integerValue,
        allRows.get(i).get("MEMBER_ID").integerValue,
        allRows.get(i).get("SERVICE_CODE").integerValue,
        allRows.get(i).get("COMMENTS").stringValue
      );
    }

    return records;
  }

  /**
   * Get all records where the service date is within the last week.
   * @return the records from last week
   */
  public static Record[] getRecordsFromLastWk() {
    SimpleDateFormat dateSDF = new SimpleDateFormat("YYYY-MM-dd");
    SimpleDateFormat dateTimeSDF = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");

    LocalDate threshold = LocalDate.now().minusDays(7);
    String formattedThreshold = threshold.format(DateTimeFormatter.ofPattern("YYYY-MM-dd"));

    ArrayList<HashMap<String, DatabaseValue>> allRows = Database.getValues("RECORDS", "SERVICE_DATE>=\""+formattedThreshold+"\"", "SERVICE_DATE ASC");

    Record[] records = new Record[allRows.size()];

    for (int i = 0; i < allRows.size(); i++) {
      Date recordedTime, serviceDate;
      try {
        recordedTime = dateTimeSDF.parse(allRows.get(i).get("RECORDED_DATE_TIME").stringValue);
        serviceDate = dateSDF.parse(allRows.get(i).get("SERVICE_DATE").stringValue);
      } catch (ParseException e) {
        recordedTime = new Date(); // should not happen
        serviceDate = new Date(); // should not happen
      }
      records[i] = new Record(
        recordedTime,
        serviceDate,
        allRows.get(i).get("PROVIDER_ID").integerValue,
        allRows.get(i).get("MEMBER_ID").integerValue,
        allRows.get(i).get("SERVICE_CODE").integerValue,
        allRows.get(i).get("COMMENTS").stringValue
      );
    }

    return records;
  }
  
  /**
   * Get all records for a particular provider whose service date is within the past week.
   * @param p the provider
   * @return the records from last week from the specified provider
   */
  public static Record[] getProviderRecordsFromLastWk(Provider p) {
    Record[] lastwksrecords = getRecordsFromLastWk();
    List<Record> providerRecordsList = new ArrayList<Record>();
    
    for (Record record:lastwksrecords) {
      if (record.getProviderId() == p.getId()) {
        providerRecordsList.add(record);
      }
    }
    
    Record[] providerRecordsArray = new Record[providerRecordsList.size()];
    return providerRecordsList.toArray(providerRecordsArray);
    
  }
  
  /**
   * Get all records for a particular member whose service date is within the past week.
   * @param m the member
   * @return the records from last week from the specified member
   */
  public static Record[] getMemberRecordsFromLastWk(Member m) {
    Record[] lastwksrecords = getRecordsFromLastWk();
    List<Record> memberRecordsList = new ArrayList<Record>();
    
    for (Record record:lastwksrecords) {
      if (record.getMemberId() == m.getId()) {
        memberRecordsList.add(record);
      }
    }
    
    Record[] memberRecordsArray = new Record[memberRecordsList.size()];
    return memberRecordsList.toArray(memberRecordsArray);
    
  }
}
