package edu.ua.cs.cs200.fall2020.team7;

import java.util.Date;

/**
 * Basic entity class for a Record.
 * @author Ashton J. (11797181)
 */
public class Record {
  private Date recordedTime;
  private Date serviceDate;
  private int providerId;
  private int memberId;
  private int serviceCode;
  private String comments;

  /**
   * Create a new record object based on the given info at the system's current time.
   * @param serviceDate The date the service was administered
   * @param providerId The provider's ID
   * @param memberId The member's ID
   * @param serviceCode The service's code
   * @param comments Relevant comments from the provider
   */
  public Record(Date serviceDate, int providerId, int memberId, int serviceCode, String comments) {
    this(new Date(), serviceDate, providerId, memberId, serviceCode, comments);
  }

  /**
   * Create a new record object based on the given info and given recorded.
   * @param recordedTime The date the service was recorded
   * @param serviceDate The date the service was administered
   * @param providerId The provider's ID
   * @param memberId The member's ID
   * @param serviceCode The service's code
   * @param comments Relevant comments from the provider
   */
  public Record(Date recordedTime, Date serviceDate, int providerId,
          int memberId, int serviceCode, String comments) {
    this.recordedTime = recordedTime;
    this.serviceDate = serviceDate;
    this.providerId = providerId;
    this.memberId = memberId;
    this.serviceCode = serviceCode;
    this.comments = comments;
  }

  /**
   * Get the recorded time.
   * @return the time
   */
  public Date getRecordedTime() {
    return this.recordedTime;
  }

  /**
   * Get the service's date.
   * @return the date
   */
  public Date getServiceDate() {
    return this.serviceDate;
  }

  /**
   * Get the provider's ID.
   * @return the id
   */
  public int getProviderId() {
    return this.providerId;
  }

  /**
   * Get the member's ID.
   * @return the id
   */
  public int getMemberId() {
    return this.memberId;
  }

  /**
   * Get the service code.
   * @return the code
   */
  public int getServiceCode() {
    return this.serviceCode;
  }

  /**
   * Get the record's comments.
   * @return the comments
   */
  public String getComments() {
    return this.comments;
  }
}
