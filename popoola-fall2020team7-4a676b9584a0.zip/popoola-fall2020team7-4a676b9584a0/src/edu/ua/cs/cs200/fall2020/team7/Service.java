package edu.ua.cs.cs200.fall2020.team7;

/**
 * Basic entity class for a Service.
 * @author Ashton J. (11797181)
 */
public class Service {
  private int id;
  private String name;
  private double fee;
  
  /**
   * Create a new service object based on the given info.
   * @param id The service's ID (also known as its code)
   * @param name The service's name
   * @param fee The service's fee
   */
  public Service(int id, String name, double fee) {
    this.id = id;
    this.name = name;
    this.fee = fee;
  }

  /**
   * Get the service ID (also known as its code).
   * @return the id
   */
  public int getId() {
    return id;
  }
  
  /**
   * Get the service name.
   * @return the name
   */
  public String getName() {
    return name;
  }
  
  /**
   * Get the service's fee.
   * @return the fee
   */
  public double getFee() {
    return fee;
  }
  
  /**
   * Get string representation.
   * For example, "Service #1234 (Service Name @ $0.01)".
   */
  public String toString() {
    return "Service #" + this.getId() + " (" + this.getName() + " @ $" + this.getFee() + ")";
  }
}
