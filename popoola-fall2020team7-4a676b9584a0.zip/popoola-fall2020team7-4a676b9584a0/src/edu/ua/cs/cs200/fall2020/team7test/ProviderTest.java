package edu.ua.cs.cs200.fall2020.team7test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import edu.ua.cs.cs200.fall2020.team7.Address;
import edu.ua.cs.cs200.fall2020.team7.Provider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ProviderTest {
  Provider providerTest;

  @BeforeEach
  void setUp() throws Exception {
    Address adr = new Address("920 Paul W Bryant Dr", "Tuscaloosa", "Alabama", 35401);
    providerTest = new Provider(123456789, "John Doe", adr);
  }

  @Test
  void testProviderIdForSuccess() {
    assertEquals(123456789, providerTest.getId(), 0);
  }

  @Test
  void testProviderNameForSuccess() {
    assertEquals("John Doe", providerTest.getName());
  }

  @Test
  void testProviderAddressForSuccess() {
    assertEquals(
        "920 Paul W Bryant Dr\nTuscaloosa, Alabama 35401", providerTest.getAddress().toString());
  }
  
  @Test
  void testProviderNameForFailure() {
    providerTest.setName("Jane Doe");
    assertNotEquals("John Doe", providerTest.getName());
  }

}
