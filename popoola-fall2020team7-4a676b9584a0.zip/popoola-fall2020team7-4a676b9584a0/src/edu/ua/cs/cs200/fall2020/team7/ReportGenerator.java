package edu.ua.cs.cs200.fall2020.team7;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;

/**
 * Entity class that generates the reports.
 * @author Raymond Arndorfer (12023919)
 */
public class ReportGenerator {
  static SimpleDateFormat dateSDF = new SimpleDateFormat("MM-dd-YYYY");
  static SimpleDateFormat datetimeSDF = new SimpleDateFormat("MM-dd-YYYY HH:mm:ss");
  
  public static void runMainAccountingProcedure() {
    Member[] allMembers = Member.getAll();
    Provider[] allProviders = Provider.getAll();
    
    for (Member member:allMembers) {
      generateMemberReport(member);
    }
    
    for (Provider provider:allProviders) {
      generateProviderReport(provider);
    }
    
    generateSummaryReport();
    generateEFTReport();
  }

  /**
   * Creates a report for a member.
   * @param member Member to create report for
   */
  public static void generateMemberReport(Member member) {
    File reportDir = setUpReportDirectory();
    Record[] memberRecords = Records.getMemberRecordsFromLastWk(member);
    
    try {
      FileWriter recordFile = new FileWriter(
          new File(reportDir, "m" + String.valueOf(member.getId()) + ".txt"), false);
      
      recordFile.append(String.format("Member Name: %s\n", member.getName()));
      recordFile.append(String.format("Member Number: %s\n", member.getId()));
      recordFile.append(String.format("Address: %s\n", member.getAddress()));
      
      recordFile.append("---\n");
      
      for (Record record:memberRecords) {
        Provider provider = AccountManagementMenu.getProvider(record.getProviderId());
        Service service = ProviderDirectory.lookupServiceByCode(record.getServiceCode());
        String line = String.format("%s: %s - %s\n",
            dateSDF.format(record.getServiceDate()), provider.getName(), service.getName());
        recordFile.append(line);
      }
      
      recordFile.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
  
  /**
   * Creates a report for a provider.
   * @param provider Provider to create report for
   */
  public static void generateProviderReport(Provider provider) {
    File reportDir = setUpReportDirectory();
    
    try {
      FileWriter recordFile = new FileWriter(
          new File(reportDir, "p" + String.valueOf(provider.getId()) + ".txt"), false);
      
      recordFile.append(String.format("Provider Name: %s\n", provider.getName()));
      recordFile.append(String.format("Provider Number: %s\n", provider.getId()));
      recordFile.append(String.format("Address: %s\n", provider.getAddress().toString()));
      
      recordFile.append("---\n");
      
      double totalFee = 0.00;
      Record[] providerRecords = Records.getProviderRecordsFromLastWk(provider);
      for (Record record:providerRecords) {
        Member member = AccountManagementMenu.getMember(record.getMemberId());
        Service service = ProviderDirectory.lookupServiceByCode(record.getServiceCode());
        
        String serviceDate = dateSDF.format(record.getServiceDate());
        String recordedDate = datetimeSDF.format(record.getRecordedTime());
        double recordfee = service.getFee();
        totalFee += recordfee;
        
        String line = String.format("%s (recorded %s): %s (%s) - %s - $%.2f\n", 
            serviceDate, recordedDate,
            member.getName(), member.getId(),
            service.getId(), recordfee);
        recordFile.append(line);
      }
      
      recordFile.append("---\n");
      
      recordFile.append(String.format("# consultations: %d\n", providerRecords.length));
      recordFile.append(String.format("Total fee: $%.2f\n", totalFee));
      
      recordFile.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static void generateSummaryReport() {
    File reportDir = setUpReportDirectory();
    
    try {
      FileWriter recordFile = new FileWriter(
          new File(reportDir, "summary.txt"), false);
      
      recordFile.append("Summary report:\n");
      
      HashMap<Integer, EFTData> paymentData = new HashMap<Integer, EFTData>();
      Record[] weeksRecords = Records.getRecordsFromLastWk();
      for (Record record:weeksRecords) {
        paymentData.putIfAbsent(record.getProviderId(), new EFTData(record.getProviderId()));
        
        Service service = ProviderDirectory.lookupServiceByCode(record.getServiceCode());
        
        paymentData.get(record.getProviderId()).addService(service);
      }
      
      double totalFee = 0.00;
      for (int providerId:paymentData.keySet()) {
        Provider provider = AccountManagementMenu.getProvider(providerId);
        EFTData providerData = paymentData.get(providerId);
        totalFee += providerData.getFee();
        recordFile.append(String.format("%s (%s): %s consultations, $%.2f\n",
            provider.getName(), provider.getId(),
            providerData.getConsultationCount(), providerData.getFee()));
      }
      
      recordFile.append("---\n");
      recordFile.append(String.format("Total providers: %s\nTotal consultations: %s\nTotal fee: %s\n", paymentData.size(), weeksRecords.length, totalFee));
      
      recordFile.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static void  generateEFTReport() {
    setUpReportDirectory();
  }
  
  static File setUpReportDirectory() {
    File directory = new File("reports");
    if (!directory.exists()) {
      directory.mkdir();
    }
    return directory;
  }
}
