package edu.ua.cs.cs200.fall2020.team7test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import edu.ua.cs.cs200.fall2020.team7.EFTData;
import edu.ua.cs.cs200.fall2020.team7.Service;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class EFTDataTest {
  EFTData testInstance;
  Service testServiceA;
  Service testServiceB;

  @BeforeEach
  void setUp() {
    testInstance = new EFTData(123456789);
    testServiceA = new Service(123, "Service A", 3.21);
    testServiceB = new Service(234, "Service B", 9.13);
    
    testInstance.addService(testServiceA);
    testInstance.addService(testServiceB);
  }

  @Test
  void testCorrectFee() {
    assertEquals(12.34, testInstance.getFee(), 0.005); // within .5¢
  }

  @Test
  void testProviderId() {
    assertEquals(123456789, testInstance.getProviderId());
  }

  @Test
  void testProviderNameForFailure() {
    assertNotEquals(3, testInstance.getConsultationCount());
  }
}
