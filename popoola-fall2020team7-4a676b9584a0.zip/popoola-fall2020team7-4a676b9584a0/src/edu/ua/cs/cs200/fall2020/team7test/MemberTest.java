package edu.ua.cs.cs200.fall2020.team7test;

import edu.ua.cs.cs200.fall2020.team7.Address;
import edu.ua.cs.cs200.fall2020.team7.Member;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MemberTest {
  Member member;
  Address address;

  @BeforeEach
  public void setUp() throws Exception {
    address = new Address("9876 Street Ave.", "Citytown", "AK", 12345);
    member = new Member(123321123, "Grace Hopper", address, false);
  }

  @Test
  void testMemberId() {
    Assertions.assertEquals(123321123, member.getId());
  }
  
  @Test
  void testMemberIdFail() {
    Assertions.assertNotEquals(123456789, member.getId());
  }

  @Test
  void testMemberName() {
    Assertions.assertEquals("Grace Hopper", member.getName());
  }
  
  @Test
  void testMemberNameFail() {
    Assertions.assertNotEquals("Ada Lovelace", member.getName());
  }

  @Test
  void testMemberAddress() {
    Assertions.assertEquals("9876 Street Ave.\nCitytown, AK 12345", member.getAddress().toString());
  }
  
  @Test
  void testMemberAddressFail() {
    Assertions.assertNotEquals("1831 Univ Blvd.\nT-town, AL 35487", member.getAddress().toString());
  }

  @Test
  void testMemberSuspended() {
    Assertions.assertEquals(false, member.isSuspended());
  }
  
  @Test
  void testMemberSuspendedFail() {
    Assertions.assertNotEquals(true, member.isSuspended());
  }
}