package edu.ua.cs.cs200.fall2020.team7;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

/**
 * Runs the Task after a certain amount of time.
 *
 * @author Ashton J. (11797181)
 */
public class Scheduler {
  /** Main function for scheduler/timer. */
  public static void main(String[] args) {
    Timer time = new Timer();
    Task st = new Task();
    long millis = System.currentTimeMillis();
    Calendar calendar = Calendar.getInstance();
    calendar.setTimeInMillis(millis);
    LocalDate curDate = LocalDate.now();
    Date date = java.sql.Date.valueOf(curDate);
    Date date2 = java.sql.Date.valueOf(timeToNextFriday(curDate));
    long timeToFriday =
        getDateDiff(date, date2, TimeUnit.MILLISECONDS)
            - (calendar.get(Calendar.HOUR_OF_DAY) * 60 * 60 * 1000)
            - (calendar.get(Calendar.MINUTE) * 60 * 1000)
            + (2 * 60 * 60 * 1000);
    time.schedule(st, timeToFriday, 604800000);
  }

  private static LocalDate timeToNextFriday(LocalDate d) {
    return d.with(TemporalAdjusters.next(DayOfWeek.FRIDAY));
  }

  private static long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
    long diffInMilli = date2.getTime() - date1.getTime();
    return timeUnit.convert(diffInMilli, TimeUnit.MILLISECONDS);
  }
}
