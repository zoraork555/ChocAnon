package edu.ua.cs.cs200.fall2020.team7;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Allows access to a list of all services.
 * @author Noah Overcash (11907775), Raymond Arndorfer (12023919)
 */
public class ProviderDirectory {
  /**
   * Get all services.
   * @return an array of all services
   */
  public static Service[] getServices() {
    ArrayList<HashMap<String, DatabaseValue>> allRows = Database.getValues("SERVICES");

    Service[] services = new Service[allRows.size()];

    for (int i = 0; i < allRows.size(); i++) {
      services[i] = new Service(
        allRows.get(i).get("ID").integerValue,
        allRows.get(i).get("NAME").stringValue,
        allRows.get(i).get("FEE").floatValue
      );
    }

    return services;
  }
  
  /**
   * Get a service by its code.
   * @param code the service's code
   * @return the service, or null if it does not exist
   */
  public static Service lookupServiceByCode(int code) {
    Service service = null;
    for (Service candidate : getServices()) {
      if (candidate.getId() == code) {
        service = candidate;
        break;
      }
    }
    return service;
  }
}
