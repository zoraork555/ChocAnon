package edu.ua.cs.cs200.fall2020.team7test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import edu.ua.cs.cs200.fall2020.team7.Address;
import edu.ua.cs.cs200.fall2020.team7.Provider;
import edu.ua.cs.cs200.fall2020.team7.Record;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/*
 * @author Ashton J.
 */
public class RecordTest {
  Record recordTest;
  Date day = new Date();

  @BeforeEach
  void setUp() throws Exception {
    recordTest = new Record(day, 123456789, 123456788, 000000, "nah");
  }
  
  @Test
  void testRecordedTimeForSuccess() {
    // 100 ms margin as Record gets the current time in its constructor
    assertEquals(day.getTime(), recordTest.getRecordedTime().getTime(), 100);
  }
  
  @Test
  void testServiceDateForSuccess() {
    assertEquals(day.getTime(), recordTest.getServiceDate().getTime());
  }


  @Test
  void testProviderIdForSuccess() {
    assertEquals(123456789, recordTest.getProviderId(), 0);
  }
  
  @Test
  void testMemberIdForSuccess() {
    assertEquals(123456788, recordTest.getMemberId(), 0);
  }
  
  @Test
  void testServiceCodeForSuccess() {
    assertEquals(000000, recordTest.getServiceCode(), 0);
  }

  @Test
  void testCommentsForSuccess() {
    assertEquals("nah", recordTest.getComments());
  }
  
  @Test
  void testCommentsForFailure() {
    assertNotEquals("no", recordTest.getComments());
  }

}
