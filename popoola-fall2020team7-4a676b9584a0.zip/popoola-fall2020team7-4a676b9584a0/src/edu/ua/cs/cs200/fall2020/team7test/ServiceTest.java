package edu.ua.cs.cs200.fall2020.team7test;

import edu.ua.cs.cs200.fall2020.team7.Service;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests the Service class.
 * @author Raymond Arndorfer (12023919)
 *
 */
public class ServiceTest {
  Service service;
  
  @BeforeEach
  public void setUp() throws Exception {
    service = new Service(1234, "Service Name", 12.34);
  }
  
  @Test
  void testStringRepr() {
    Assertions.assertEquals("Service #1234 (Service Name @ $12.34)", service.toString());
  }
  
  @Test
  void testID() {
    Assertions.assertEquals(1234, service.getId());
  }
  
  @Test
  void testNameFail() {
    Assertions.assertNotEquals("Service Test", service.getName());
  }
}
